// SmartAttend logic. Data is stored in the browser (localStorage) under the key below.
const $ = s => document.querySelector(s);
const pad = n => String(n).padStart(2, "0");
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const DAYNAME = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const KEY = "smartattend.register.v1";
const today = new Date(); today.setHours(0, 0, 0, 0);
const todayIso = iso(today);

function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function seed() {
  const names = ["Aarav Sharma","Diya Reddy","Rohan Verma","Sneha Iyer","Kiran Rao","Meera Nair","Arjun Singh","Isha Gupta","Vikram Patel","Anaya Khan"];
  const students = names.map((n, i) => ({id: i + 1, roll: "CS" + pad(i + 1), name: n}));
  const courses = [
    {id: 1, code: "DBMS", name: "Database Systems", days: [1, 3, 5]},
    {id: 2, code: "API",  name: "Backend APIs",     days: [2, 4]},
    {id: 3, code: "WEB",  name: "Web Technologies", days: [1, 4, 6]}];
  const r = rng(7), marks = {};
  for (let back = 1; back <= 75; back++) {
    const d = new Date(today); d.setDate(today.getDate() - back);
    for (const c of courses) if (c.days.includes(d.getDay())) for (const s of students) {
      const p = (s.id === 3 || s.id === 7) ? 0.55 : 0.9;
      marks[`${c.id}|${iso(d)}|${s.id}`] = r() < p ? "P" : (p < 0.6 ? "A" : (r() < 0.5 ? "A" : "L"));
    }
  }
  return {students, courses, marks, threshold: 75, nextId: 11};
}
function load() { try { const x = localStorage.getItem(KEY); if (x) return JSON.parse(x); } catch (e) {} return seed(); }
function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }

let S = load(), courseId = S.courses[0].id, month = todayIso.slice(0, 7), query = "", lastKey = null;
const course = () => S.courses.find(c => c.id === courseId);
const mk = (dIso, sid) => `${courseId}|${dIso}|${sid}`;

function classDays() {
  const [y, m] = month.split("-").map(Number), n = new Date(y, m, 0).getDate(), out = [];
  for (let d = 1; d <= n; d++) { const dt = new Date(y, m - 1, d); if (course().days.includes(dt.getDay())) out.push(dt); }
  return out;
}
function say(t) { $("#live").textContent = t; }

function render() {
  const ds = classDays(), th = S.threshold;
  $("#th").value = th; $("#month").value = month; summary();
  $("#tabs").innerHTML = S.courses.map(c =>
    `<button role="tab" aria-selected="${c.id === courseId}" data-c="${c.id}"><b>${esc(c.code)}</b><span>${esc(c.name)}: ${c.days.map(d => DAYNAME[d]).join(", ")}</span></button>`).join("");

  const stats = S.students.map(s => {
    let a = 0, t = 0;
    for (const d of ds) { const v = S.marks[mk(iso(d), s.id)]; if (v) { t++; if (v !== "A") a++; } }
    return {s, p: t ? Math.round(100 * a / t) : null};
  });

  // summary for one focus date
  const marked = ds.filter(d => S.students.some(s => S.marks[mk(iso(d), s.id)]));
  const focus = ds.find(d => iso(d) === todayIso) || marked[marked.length - 1];
  if (focus) {
    const c = {P: 0, A: 0, L: 0}, f = iso(focus);
    S.students.forEach(s => { const v = S.marks[mk(f, s.id)]; if (v) c[v]++; });
    const label = focus.toLocaleDateString(undefined, {weekday: "long", day: "numeric", month: "long"});
    $("#line").innerHTML = `${label}: <span class="cnt P">${c.P} present</span>, <span class="cnt A">${c.A} absent</span>, <span class="cnt L">${c.L} on leave</span>.`;
  } else $("#line").textContent = "No classes to show for this month.";
  const low = stats.filter(x => x.p !== null && x.p < th);
  $("#alert").innerHTML = low.length
    ? `Below ${th}% this month: ` + low.map(x => `<b>${esc(x.s.name.split(" ")[0])}</b> (${x.p}%)`).join(", ") + "."
    : `Everyone with recorded classes is at or above ${th}%.`;

  const rows = stats.filter(x => (x.s.name + x.s.roll).toLowerCase().includes(query));
  if (!ds.length || !rows.length) { $("#reg").innerHTML = `<div class="empty">${ds.length ? "No student matches your search." : "This course has no class days this month."}</div>`; return; }

  const head = ds.map(d => {
    const f = iso(d); let p = 0, t = 0;
    S.students.forEach(s => { const v = S.marks[mk(f, s.id)]; if (v) { t++; if (v !== "A") p++; } });
    return `<th class="day ${f === todayIso ? "today" : ""}"><button data-day="${f}" title="Mark everyone present on ${f}">${DAYNAME[d.getDay()]}<span class="d">${d.getDate()}</span><i style="--w:${t ? Math.round(100 * p / t) : 0}%"></i></button></th>`;
  }).join("");

  const body = rows.map(({s, p}) => {
    const isLow = p !== null && p < th;
    const cells = ds.map(d => {
      const f = iso(d), v = S.marks[mk(f, s.id)] || "", fut = f > todayIso;
      const lab = {P: "present", A: "absent", L: "on leave", "": "not marked"}[v];
      return `<td><button class="m ${v}" data-k="${mk(f, s.id)}" ${fut ? "disabled" : ""} aria-label="${esc(s.name)}, ${f}: ${lab}">${v}</button></td>`;
    }).join("");
    return `<tr><th scope="row" class="who ${isLow ? "low" : ""}" style="--w:${p ?? 0}%"><span class="nm"><b><button class="lk" data-stu="${s.id}" title="Open report card">${esc(s.name)}</button></b><small>${esc(s.roll)}</small></span><span class="pc ${isLow ? "low" : ""}">${p === null ? "-" : p + "%"}</span><button class="rm" data-rm="${s.id}" aria-label="Remove ${esc(s.name)}">&times;</button></th>${cells}</tr>`;
  }).join("");

  $("#reg").innerHTML = `<table><thead><tr><th class="corner" scope="col"><span style="padding-left:10px;font-size:12px;color:var(--mut)">Student and attendance</span></th>${head}</tr></thead><tbody>${body}</tbody></table>`;
  if (lastKey) { const el = document.querySelector(`[data-k="${lastKey}"]`); if (el) el.focus(); }
}

// ---- events ----
$("#reg").addEventListener("click", e => {
  const cell = e.target.closest("[data-k]"), day = e.target.closest("[data-day]"), rm = e.target.closest("[data-rm]"), stu = e.target.closest("[data-stu]");
  if (stu) { openCard(+stu.dataset.stu); }
  else if (cell) {
    const k = cell.dataset.k, order = ["", "P", "A", "L"], cur = S.marks[k] || "", next = order[(order.indexOf(cur) + 1) % 4];
    next ? S.marks[k] = next : delete S.marks[k];
    lastKey = k; save(); render();
  } else if (day) {
    S.students.forEach(s => { S.marks[mk(day.dataset.day, s.id)] = "P"; });
    lastKey = null; save(); render(); say(`Marked everyone present on ${day.dataset.day}.`);
  } else if (rm) {
    const s = S.students.find(x => x.id === +rm.dataset.rm);
    if (s && confirm(`Remove ${s.name} and their attendance records?`)) {
      S.students = S.students.filter(x => x.id !== s.id);
      Object.keys(S.marks).forEach(k => { if (k.endsWith("|" + s.id)) delete S.marks[k]; });
      lastKey = null; save(); render(); say(`${s.name} removed.`);
    }
  }
});
$("#tabs").addEventListener("click", e => { const b = e.target.closest("[data-c]"); if (b) { courseId = +b.dataset.c; lastKey = null; render(); } });
$("#month").addEventListener("change", e => { if (e.target.value) { month = e.target.value; lastKey = null; render(); } });
$("#q").addEventListener("input", e => { query = e.target.value.trim().toLowerCase(); lastKey = null; render(); });
$("#th").addEventListener("change", e => { S.threshold = Math.min(100, Math.max(0, +e.target.value || 75)); save(); render(); });
$("#add").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("#nn").value.trim(); if (!name) return;
  const roll = $("#nr").value.trim() || "CS" + pad(S.nextId);
  if (S.students.some(s => s.roll.toLowerCase() === roll.toLowerCase())) { say(`Roll number ${roll} is already used. Choose another.`); return; }
  S.students.push({id: S.nextId++, roll, name}); save(); $("#add").reset(); render(); say(`${name} added. Click their boxes to mark attendance.`);
});
$("#reset").addEventListener("click", () => {
  if (confirm("Replace everything with the demo data?")) { S = seed(); save(); courseId = S.courses[0].id; lastKey = null; render(); say("Demo data restored."); }
});
$("#csv").addEventListener("click", () => {
  const ds = classDays(), q = v => `"${String(v).replace(/"/g, '""')}"`;
  const lines = [["Roll", "Name", ...ds.map(iso), "Attendance %"].map(q).join(",")];
  S.students.forEach(s => {
    let a = 0, t = 0;
    const cells = ds.map(d => { const v = S.marks[mk(iso(d), s.id)] || ""; if (v) { t++; if (v !== "A") a++; } return v; });
    lines.push([s.roll, s.name, ...cells, t ? Math.round(100 * a / t) : ""].map(q).join(","));
  });
  const url = URL.createObjectURL(new Blob([lines.join("\n")], {type: "text/csv"}));
  const a = Object.assign(document.createElement("a"), {href: url, download: `attendance-${course().code}-${month}.csv`});
  a.click(); URL.revokeObjectURL(url); say("CSV downloaded.");
});

// ---- course summary, student report card, backup, print ----
function summary() {
  $("#sum").innerHTML = S.courses.map(c => {
    let a = 0, t = 0;
    for (const k in S.marks) if (k.startsWith(c.id + "|")) { t++; if (S.marks[k] !== "A") a++; }
    const p = t ? Math.round(100 * a / t) : 0;
    return `<span class="chip"><b>${esc(c.code)}</b> ${p}% overall<i style="--w:${p}%"></i></span>`;
  }).join("");
}
function openCard(id) {
  const s = S.students.find(x => x.id === id); if (!s) return;
  let A = 0, T = 0;
  const rows = S.courses.map(c => {
    let a = 0, t = 0; const ab = [];
    for (const k in S.marks) {
      const [cid, d, sid] = k.split("|");
      if (+cid === c.id && +sid === id) { t++; if (S.marks[k] === "A") ab.push(d); else a++; }
    }
    A += a; T += t;
    const p = t ? Math.round(100 * a / t) : null;
    return `<tr><td>${esc(c.code)}</td><td>${a} of ${t}</td><td class="${p !== null && p < S.threshold ? "lowtxt" : ""}">${p === null ? "-" : p + "%"}</td><td>${ab.sort().slice(-2).join(", ") || "none"}</td></tr>`;
  }).join("");
  const all = T ? Math.round(100 * A / T) : null;
  $("#card-body").innerHTML = `<h2>${esc(s.name)}</h2><p>${esc(s.roll)}, ${all === null ? "no records yet" : `overall attendance <b class="${all < S.threshold ? "lowtxt" : ""}">${all}%</b>`}</p>
    <table><tr><th>Course</th><th>Attended</th><th>%</th><th>Latest absences</th></tr>${rows}</table>`;
  $("#card").showModal();
}
$("#print").addEventListener("click", () => window.print());
$("#backup").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([JSON.stringify(S, null, 2)], {type: "application/json"}));
  const a = Object.assign(document.createElement("a"), {href: url, download: "smartattend-backup.json"});
  a.click(); URL.revokeObjectURL(url); say("Backup downloaded.");
});
$("#restore").addEventListener("change", e => {
  const f = e.target.files[0]; if (!f) return;
  f.text().then(t => {
    const d = JSON.parse(t);
    if (!Array.isArray(d.students) || !Array.isArray(d.courses) || !d.courses.length || typeof d.marks !== "object") throw 0;
    S = d; S.threshold = S.threshold || 75; S.nextId = S.nextId || Math.max(0, ...S.students.map(x => x.id)) + 1;
    courseId = S.courses[0].id; save(); render(); say("Backup restored.");
  }).catch(() => say("That file is not a valid SmartAttend backup.")).finally(() => { e.target.value = ""; });
});
render();
