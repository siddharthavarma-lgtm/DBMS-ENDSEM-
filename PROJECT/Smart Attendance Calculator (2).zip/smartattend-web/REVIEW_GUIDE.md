# Review guide: SmartAttend

## One-line summary
A web-based class register where a teacher marks Present, Absent or Leave with one click, sees each
student's attendance percentage instantly, and gets a warning when a student falls below the minimum.

## Problem it solves
Paper registers are slow to total up, easy to get wrong, and defaulters are noticed late.
SmartAttend calculates percentages live and flags students below the required limit (default 75%).

## 5-minute demo (in this order)
1. **Open the page.** Point out the top line (today's counts) and the red warning naming the low students.
2. **Mark today's class.** Click today's date to mark everyone present, then click two students to make them Absent and Leave.
3. **Show live results.** The percentages, the bar behind each name and the summary line change immediately.
4. **Open a report card.** Click a low-attendance student's name and show the per-course table.
5. **Change the minimum** to 90 and show more students turning red.
6. **Switch course and month.** Each course has its own class days.
7. **Add a student**, then search for them.
8. **Export CSV and Print report.** Say the register can be shared or filed.
9. **Backup and Restore.** Say the data is stored in the browser and can be moved between computers.

## Features to list on your slide
- One-click marking with three statuses (Present, Absent, Leave)
- Mark a whole class present in one click
- Live percentage per student, with warning colours below the minimum
- Course-wise and month-wise views, with each course's own timetable days
- Student report card, course summary, search
- Add and remove students
- CSV export, printable report, JSON backup and restore
- Works offline, no install, dark mode, keyboard accessible

## Technology (say it in this order)
- **HTML** builds the page structure.
- **CSS** styles it, using variables for colours so dark mode is one small block.
- **JavaScript** holds the data in an object, calculates percentages, draws the register table,
  and saves to the browser's `localStorage` after every change.

## Likely questions and answers
1. **Where is the data stored?** In the browser's localStorage as JSON. It stays after a refresh.
2. **How is the percentage calculated?** (Present + Leave) divided by classes marked. Blank boxes are not counted.
3. **Why does Leave count as attended?** Approved leave is treated as excused, as many colleges do. It is one line to change.
4. **Why no future dates?** Attendance can only be recorded for classes that have happened.
5. **What if two teachers use it?** This version stores data per browser. A shared version needs a database and a server, which is the next step.
6. **How would you add a database?** Move the data functions to a backend API (for example FastAPI with SQLite or PostgreSQL) and call it with `fetch`.
7. **How do you stop wrong entries?** Boxes can be edited again, and the roll number must be unique.
8. **What are the limitations?** No real login and no multi-user sync yet. Be upfront: this is a front-end project, and you know how to extend it.
9. **What would you add next?** Login with roles, parent SMS or email alerts for defaulters, a database backend, and charts.
10. **How is it secure?** Text from users is escaped before it is shown, so pasted HTML cannot run.

## Tips for full marks
- Run through the demo twice before the review, and reset demo data first.
- Keep a printed report and the CSV file ready to show.
- Know where `render()`, `save()` and the percentage calculation are in `script.js` and be ready to open them.
- Add a title slide with the problem, features, technology, demo screenshots and future scope.
