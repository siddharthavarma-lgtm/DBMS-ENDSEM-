# SmartAttend - Class register (HTML, CSS, JavaScript)

Three files, no installs, no server:

| File | Language | What it does |
|---|---|---|
| `index.html` | HTML | Page structure: header, course tabs, register table, add-student form |
| `style.css` | CSS | Look and feel, colours, dark mode, sticky name column |
| `script.js` | JavaScript | Data, marking logic, percentages, search, CSV export |

## Run it in VS Code
1. **File > Open Folder** and select this folder.
2. Install the **Live Server** extension, right-click `index.html`, choose **Open with Live Server**.
   (Double-clicking `index.html` also works.)

## Use it
- Click a course tab, then click a box to cycle Present, Absent, Leave, blank.
- Click a date to mark everyone present. Percentages update instantly.
- Add or remove students, search, change the minimum percentage, export CSV.
- Data is saved in your browser (localStorage). "Reset demo data" restores the sample class.

## Where things are in script.js
`seed()` demo data, `load()` and `save()` storage, `render()` draws the register,
the click handlers at the bottom do the marking.

## Extra features
- **Report card:** click any student's name to see attendance per course and their latest absences.
- **Course summary:** the chips at the top show overall attendance for each course.
- **Print report:** prints the register on paper or saves it as a PDF.
- **Backup / Restore:** download all data as a JSON file and load it back later.

See `REVIEW_GUIDE.md` for the demo script and viva answers.
